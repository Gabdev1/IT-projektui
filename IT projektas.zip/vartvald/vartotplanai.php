<?php
// vartotplanai.php  Parodoma registruotų vartotojų lentelė ir jų planai

session_start();
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Vartotojai ir jų planai</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
            <center><img src="include/top.png"></center>
        </td></tr><tr><td> 
 <?php
		include("include/meniu.php"); //įterpiamas meniu pagal vartotojo rolę
 			$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
			$sql = "SELECT username, email, operatoriai.pavadinimas, planai.planpavadinimas, planai.kaina FROM `vartotojai`, `planai`, `operatoriai` WHERE planas = planai.id AND planai.operatorius = operatoriai.id";
			$result = mysqli_query($db, $sql);
			if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Klaida skaitant lentelę vartotojai ir planai"; exit;}
 ?> 

        <center><font size="5">Vartotojai ir jų planai</font></center><br>
		
    <table class="center" border="1" cellspacing="0" cellpadding="3">
    <tr><td><b>Vartotojo vardas</b></td><td><b>E-paštas</b></td><td><b>Operatorius</b></td><td><b>Plano pavadinimas</b></td><td><b>Kaina</b></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $username=$row['username'];
	    $email=$row['email']; 
        $operatorius=$row['pavadinimas']; 
	  	$planpav= $row['planpavadinimas'];
        $kaina=$row['kaina'];
		    echo "<tr><td>".$username. "</td><td>";  
            echo $email. "</td><td>"; 
            echo $operatorius. "</td><td>"; 
 			echo $planpav. "</td><td>";  
		    echo $kaina."</td></tr>"; 
      		
	}
 ?>
	  </table>	
  </body></html>