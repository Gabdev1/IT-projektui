<?php
// planas.php  Parodomas vartotojo pokalbių planas

session_start();
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}

?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Vartotojo pokalbių planas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
            <center><img src="include/top.png"></center>
        </td></tr><tr><td> 
 <?php
		include("include/meniu.php"); //įterpiamas meniu pagal vartotojo rolę
 			$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
			$sql = "SELECT operatoriai.pavadinimas, planai.planpavadinimas, skambuciai, skambuzs, zinutes, zinuzs, internetas, internuzs, kaina FROM  `operatoriai`, `planai`, `vartotojai` WHERE planai.operatorius = operatoriai.id AND vartotojai.planas = planai.id AND vartotojai.username = 'gabriele'";
			$result = mysqli_query($db, $sql);
			if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Klaida skaitant lentelę planai, vartotojai ir operatoriai"; exit;}
 ?> 
        <center><font size="5">Jūsų planas</font></center><br>
		
    <table class="center" border="1" cellspacing="0" cellpadding="3">
    <tr><td><b>Operatorius</b></td><td><b>Pavadinimas</b></td><td><b>Skambučiai (min)</b></td><td><b>Skambučiai užsienyje (min)</b></td><td><b>Žinutes</b></td><td><b>Žinutės užsienyje</b></td><td><b>Internetas (GB)</b></td><td><b>Internetas užsienyje (GB)</b></td><td><b>Kaina (eur)</b></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $oppav=$row['pavadinimas'];
	    $planpav=$row['planpavadinimas']; 
	  	$skambuciai= $row['skambuciai'];
		$skambuzs=$row['skambuzs'];
        $zinutes=$row['zinutes'];
        $zinuzs=$row['zinuzs'];
        $internetas=$row['internetas'];
        $internuzs=$row['internuzs'];
        $kaina=$row['kaina'];
		    echo "<tr><td>".$oppav. "</td><td>";  
            echo $planpav. "</td><td>"; 
 			echo $skambuciai. "</td><td>";  
            echo $skambuzs. "</td><td>";  
            echo $zinutes. "</td><td>";  
            echo $zinuzs. "</td><td>";  
            echo $internetas. "</td><td>";  
            echo $internuzs. "</td><td>";  
		    echo $kaina."</td></tr>";       		
	}
 ?>
	  </table>
  </body></html>