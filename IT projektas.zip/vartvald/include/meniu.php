<?php
// meniu.php  rodomas meniu pagal vartotojo rolę

if (!isset($_SESSION)) { header("Location: logout.php");exit;}
include("include/nustatymai.php");
$user=$_SESSION['user'];
$userlevel=$_SESSION['ulevel'];
$role="";
{foreach($user_roles as $x=>$x_value)
			      {if ($x_value == $userlevel) $role=$x;}
} 

     echo "<table width=100% border=\"0\" cellspacing=\"1\" cellpadding=\"3\" class=\"meniu\">";
        echo "<tr><td>";
        echo "Prisijungęs vartotojas: <b>".$user."</b>     Rolė: <b>".$role."</b> <br>";
        echo "</td></tr><tr><td>";
        if ($_SESSION['user'] != "guest") echo "[<a href=\"useredit.php\">Redaguoti paskyrą</a>] &nbsp;&nbsp;";
        echo "[<a href=\"3pop.php\">TOP 3 populiariausi planai</a>] &nbsp;&nbsp;";
		//Vartotojų sąsaja:
        if (($userlevel == $user_roles["Vartotojas"])) {
            echo "[<a href=\"planas.php\">Planas</a>] &nbsp;&nbsp;";
       		}   
    	 //Operatorių sąsaja:
        if (($userlevel == $user_roles["Operatorius"])) {
            echo "[<a href=\"planai.php\">Pokalbių planai</a>] &nbsp;&nbsp;";
			echo "[<a href=\"vartotplanai.php\">Vartotojai ir jų planai</a>] &nbsp;&nbsp;";
       		}   
        //Administratoriaus sąsaja rodoma tik administratoriui
        if ($userlevel == $user_roles[ADMIN_LEVEL] ) {
			echo "[<a href=\"vartot.php\">Vartotojai</a>] &nbsp;&nbsp;";
            echo "[<a href=\"admin.php\">Administratoriaus sąsaja</a>] &nbsp;&nbsp;";
        }
        echo "[<a href=\"logout.php\">Atsijungti</a>]";
      echo "</td></tr></table>";
?>       
    
 