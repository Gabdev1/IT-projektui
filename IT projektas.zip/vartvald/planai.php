<?php
// planai.php  Parodomi planai

session_start();
if (!isset($_SESSION['prev']) || ($_SESSION['prev'] != "index"))
{ header("Location: logout.php");exit;}
    
?>
<?php
$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "planai";
// prisijungimas prie DB
$db=mysqli_connect($server,$user,$password, $db);
if(!$db){ die ("Negaliu prisijungti prie MySQL:"
.mysqli_error($dbc)); }
//if (isset($_POST["ok"]))
if($_POST !=null){
// įrašyti reikšmes iš formos
$planpavadinimas = $_POST['planpavadinimas'];
$skambuciai =$_POST['skambuciai'];
$skambuzs =$_POST['skambuzs'];
$zinutes =$_POST['zinutes'];
$zinuzs =$_POST['zinuzs'];
$internetas =$_POST['internetas'];
$internuzs =$_POST['internuzs'];
$kaina =$_POST['kaina'];
$operatorius =$_POST['operatorius'];
$sql = "INSERT INTO $lentele (planpavadinimas, skambuciai, skambuzs, zinutes, zinuzs, internetas, internuzs, kaina, operatorius ) VALUES ('$planpavadinimas', '$skambuciai', '$skambuzs', '$zinutes', '$zinuzs', '$internetas', '$internuzs', '$kaina', '$operatorius' )";
if (!mysqli_query($db, $sql)) die ("Klaida
įrašant:" .mysqli_error($db));
}
?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Planai</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
            <center><img src="include/top.png"></center>
        </td></tr><tr><td> 

<?php
    include("include/meniu.php"); //įterpiamas meniu pagal vartotojo rolę
        $sql = "SELECT * FROM $lentele";
		$result = mysqli_query($db, $sql);
		if (!$result || (mysqli_num_rows($result) < 1))  
		{echo "Klaida skaitant lentelę planai ir operatoriai"; exit;}
?>
    
        <center><font size="5">Pokalbių planai</font></center><br>
		
    <table class="center" border="1" cellspacing="0" cellpadding="3">
    <tr><td><b>Plano ID</b></td><td><b>Pavadinimas</b></td><td><b>Skambučiai (min)</b></td><td><b>Skambučiai užsienyje (min)</b></td><td><b>Žinutes</b></td><td><b>Žinutės užsienyje</b></td><td><b>Internetas (GB)</b></td><td><b>Internetas užsienyje (GB)</b></td><td><b>Kaina (eur)</b></td><td><b>Operatoriaus ID</b></td></tr>
            
<?php
while($row = mysqli_fetch_assoc($result))
{   
        $id=$row['id'];
	    $planpav=$row['planpavadinimas']; 
	  	$skambuciai= $row['skambuciai'];
		$skambuzs=$row['skambuzs'];
        $zinutes=$row['zinutes'];
        $zinuzs=$row['zinuzs'];
        $internetas=$row['internetas'];
        $internuzs=$row['internuzs'];
        $kaina=$row['kaina'];
        $operatorius=$row['operatorius'];
		    echo "<tr><td>".$id. "</td><td>";  
            echo $planpav. "</td><td>"; 
 			echo $skambuciai. "</td><td>";  
            echo $skambuzs. "</td><td>";  
            echo $zinutes. "</td><td>";  
            echo $zinuzs. "</td><td>";  
            echo $internetas. "</td><td>";  
            echo $internuzs. "</td><td>";  
            echo $kaina. "</td><td>";  
		    echo $operatorius."</td></tr>";  
}
echo "</table>";
echo "<br>";
 ?>
        
        <center><font size="5">Sukurti naują planą:</font></center><br>
<div class="container">
<form method='post'>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="planpavadinimas" class="control-label">Sukurti plano pavadinimą:</label>
    <input name='planpavadinimas' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="skambuciai" class="control-label">Skambučių trukmė (minutėmis):</label>
    <input name='skambuciai' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="skambuzs" class="control-label">Skambučių trukmė užsienyje (minutėmis):</label>
    <input name='skambuzs' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="zinutes" class="control-label">Žinučių kiekis:</label>
    <input name='zinutes' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="zinuzs" class="control-label">Žinučių kiekis užsienyje:</label>
    <input name='zinuzs' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="internetas" class="control-label">Interneto kiekis (GB):</label>
    <input name='internetas' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="internuzs" class="control-label">Interneto kiekis užsienyje (GB):</label>
    <input name='internuzs' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="kaina" class="control-label">Įvesti kainą:</label>
    <input name='kaina' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
    <label for="operatorius" class="control-label">Pasirinkti operatorių:</label>
    <input name='operatorius' type='text' class="form-control input-sm">
</div>
<div class="form-group col-xs-3 col-md-6 col-lg-4">
<input type='submit' name='ok' value='Pridėti naują planą' class="btnbtn-default">
</div>
</form>
</div>
        
	  </table>
                        

  </body></html>